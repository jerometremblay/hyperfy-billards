import { build } from 'esbuild'
import { mkdtemp, readFile } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import { fileURLToPath } from 'node:url'
import { resolve } from 'node:path'
import vm from 'node:vm'
import * as THREE from 'three'
export const root = fileURLToPath(new URL('../', import.meta.url))
const temp = await mkdtemp(`${tmpdir()}/hyperfy-billard-test-`)
await build({
  stdin: { contents: "export * from './src/simulation.js'; export * from './src/aim.js'; export * from './src/stroke.js'; export * from './src/player-pose.js'", resolveDir: root },
  bundle: true,
  format: 'esm',
  platform: 'node',
  outfile: `${temp}/simulation.mjs`,
})
export const physics = await import(`${temp}/simulation.mjs`)
await build({
  stdin: {
    contents:
      ['Prim', 'Group', 'Action', 'UI', 'UIText', 'Audio', 'Light', 'RigidBody', 'Collider']
        .map(n => `export { ${n} } from './src/core/nodes/${n}.js'`)
        .join(';') + "; export { importApp, exportApp } from './src/core/extras/appTools.js'",
    resolveDir: process.env.HYPERFY_ROOT ? resolve(process.env.HYPERFY_ROOT) : `${root}vendor/hyperfy`,
  },
  bundle: true,
  format: 'esm',
  platform: 'node',
  outfile: `${temp}/nodes.mjs`,
})
export const nodes = await import(`${temp}/nodes.mjs`)
const constructors = { prim: nodes.Prim, group: nodes.Group, action: nodes.Action, ui: nodes.UI, uitext: nodes.UIText, audio: nodes.Audio, light: nodes.Light, rigidbody: nodes.RigidBody, collider: nodes.Collider }
export const code = await readFile(`${root}dist/hyperfy-billard.js`, 'utf8')
let nextInstanceId = 0
export function harness({ instanceId = `test-app-${++nextInstanceId}`, server = false, state = {}, props = {}, players = [], source = code, bus = {}, cueHolders, modelNodes = {} } = {}) {
  const handlers = {},
    created = [],
    appChildren = [],
    sent = [],
    audioPlays = []
  let now = 0, nextTimer = 0
  const timers = []
  const setTimeout = (fn, delay) => {
    const id = ++nextTimer
    timers.push({ id, fn, at: now + delay })
    return id
  }
  const advance = ms => {
    now += ms
    let calls = 0
    while (true) {
      timers.sort((a, b) => a.at - b.at)
      const timer = timers[0]
      if (!timer || timer.at > now) break
      timers.shift()
      timer.fn()
      if (++calls > 1000) throw new Error('timer runaway')
    }
  }
  let actionPrompts = []
  let released = 0
  let control = null, activeControl = null
  const pointer = { coords: new THREE.Vector3(0.5, 0.5, 0), position: new THREE.Vector3(), delta: new THREE.Vector3(), locked: false,
    lock() { this.locked = true }, unlock() { this.locked = false } }
  const app = {
    instanceId,
    position: new THREE.Vector3(0, 0.762, 0),
    quaternion: new THREE.Quaternion(),
    scale: new THREE.Vector3(1, 1, 1),
    state,
    configuredFields: [],
    configure(fields) { this.configuredFields = fields },
    get(id) { return modelNodes[id] || null },
    add(node) { appChildren.push(node) },
    remove() {},
    create(type, data) {
      const n = new constructors[type](data)
      n.activate = n.deactivate = () => {}
      // Keep real Audio properties/proxies; replace only the browser audio backend.
      if (type === 'audio') {
        n.play = () => audioPlays.push({ src: n.src, volume: n.volume, position: n.position.clone(), node: n })
        n.stop = () => { n.stops = (n.stops || 0) + 1 }
      }
      created.push(n)
      return n.getProxy()
    },
    on(name, fn) {
      ;(handlers[name] ||= []).push(fn)
    },
    off(name, fn) {
      handlers[name] = (handlers[name] || []).filter(f => f !== fn)
    },
    emit(name, value) {
      world.emit(name, value)
    },
    send(name, value) {
      sent.push([name, structuredClone(value)])
      app.deliver?.(name, structuredClone(value))
    },
    control() {
      control?.release()
      let done = false
      const boundControl = new Proxy(
        {
          camera: { position: new THREE.Vector3(), quaternion: new THREE.Quaternion() },
          pointer,
          scrollDelta: { value: 0 },
          setActions(value) { actionPrompts = value || [] },
          release() {
            if (!done) released++
            done = true
            if (activeControl === boundControl) activeControl = null
          },
        },
        {
          get(target, key) {
            return target[key] ?? (target[key] = { down: false })
          },
        }
      )
      control = boundControl
      activeControl = control
      return control
    },
  }
  const worldEvents = bus
  const world = {
    add() {},
    remove() {},
    on(name, callback) {
      ;(worldEvents[name] ||= []).push(callback)
    },
    off(name, callback) {
      worldEvents[name] = (worldEvents[name] || []).filter(fn => fn !== callback)
    },
    emit(name, value) {
      for (const callback of worldEvents[name] || []) callback(value)
    },
    isServer: server,
    isClient: !server,
    getPlayers: () => players,
    getPlayer: id => (id ? players.find(p => p.id === id) : players[0]),
    getTime: () => now / 1000,
  }
  if (cueHolders) {
    const cueEvent = 'billard:cues'
    world.on(`${cueEvent}:request`, () => world.emit(cueEvent, { rackId: 'test-rack', holders: cueHolders }))
  }
  vm.runInNewContext(
    `(function(world, app, fetch, props, setTimeout) { const config = props\n${source}\n})(world, app, undefined, props, setTimeout)`,
    { app, world, props, setTimeout, Date: { now: () => now }, console, Vector3: THREE.Vector3, Quaternion: THREE.Quaternion, Euler: THREE.Euler },
    { timeout: 5000 }
  )
  return {
    app,
    world,
    handlers,
    created,
    appChildren,
    sent,
    audioPlays,
    advance,
    advanceTime: seconds => advance(seconds * 1000),
    get pendingTimers() { return timers.length },
    get actionPrompts() { return actionPrompts },
    get activeControl() { return activeControl },
    get control() {
      activeControl = control
      return control
    },
    get released() {
      return released
    },
    emit(name, value, sender) {
      if (name === 'update' && Number.isFinite(value) && value > 0) advance(value * 1000)
      for (const fn of handlers[name] || []) fn(value, sender)
      // Native frame order positions app cameras after the avatar animation update.
      if (name === 'update') for (const fn of handlers.lateUpdate || []) fn(value)
    },
  }
}
export function player(id, networkId = id) {
  return { id, networkId, poseCalls: [], poseOptionsCalls: [], setPose(pose, options) { this.poseCalls.push(structuredClone(pose)); this.poseOptionsCalls.push(structuredClone(options)); this.pose = pose; return true }, cameraCalls: [], setCamera(options) { this.cameraCalls.push({...options, target: options.target?.clone(), quaternion: options.quaternion?.clone()}) }, position: new THREE.Vector3(0, 0, 1.5), quaternion: new THREE.Quaternion(),
    teleport(position, yaw) { this.position.copy(position); this.quaternion.setFromEuler(new THREE.Euler(0, yaw, 0)) } }
}
