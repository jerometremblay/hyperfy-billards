import { Vector3, Quaternion, Euler } from 'three'
import { BALL_RADIUS as R } from './simulation.js'
import { createSounds } from './sound.js'
import { CUE_EVENT, POSE_EVENT, AIM_DATA_EVENT, watchCues } from './cues.js'
import { shotPose, avatarStance, placementStance, AIM_ELEVATION } from './aim.js'
import { playerAimPose, playerPlacementPose, playerMeasurements } from './player-pose.js'
import { strokePose, STROKE_END } from './stroke.js'
import { createAimHud } from './hud.js'

export function startClient(world, app, { balls, ghost, surfaceTarget, size, playChannel, soundSources }) {
  if (!world.getPlayer) return
  const me = world.getPlayer()
  if (!me) {
    const ready = () => {
      if (!world.getPlayer()) return
      world.off('player', ready)
      startClient(world, app, { balls, ghost, surfaceTarget, size, playChannel, soundSources })
    }
    world.on('player', ready)
    return
  }
  let latest = app.state?.pool, frames = [], clock = 0, control = null, idle = null
  let pending = false, requestedAt = 0, shotPending = false, shotRequestSeq = -1, ping = 0, sinceAim = 0
  let angle = 0, speed = 2.5, side = 0, top = 0
  let cameraOrbit = 0, floorY = 0, cueElevation = Math.atan(0.045)
  let aimStance = null
  let placeX = -size.length / 4, placeY = 0
  let cueHolders = latest?.cueHolders || [], aim = app.state?.aim, posedPlayer = null
  const sounds = createSounds(app, soundSources || {})
  const volumeEvent = `billard:volume:${playChannel}`
  world.on(volumeEvent, value => sounds.setVolume(value))
  app.emit(`${volumeEvent}:request`)
  let poseMeasurements = null, savedCamera = null, cameraHold = null, aimCue = null
  let aimCameraPosition = null, aimCameraTarget = null, strokePlayback = null, completedStrokeId = -1
  const riseDuration = 1
  let aimEntry = null, posedBody = false, poseEntryAt = null, aimCameraPending = false
  let posedBridgeType = null, cueEntryUntil = 0
  let soundEvents = [], lastEventId = latest?.lastEventId || 0
  const cueEvent = CUE_EVENT
  const aimingEvent = `billard:aiming:${playChannel}`
  const poseEvent = POSE_EVENT
  const hasCue = () => cueHolders.includes(me.id)
  const canPlay = () => hasCue() && !control && !cameraHold && !pending && !shotPending && !latest?.moving && !latest?.stroke && !latest?.owner
  const ui = app.create('ui', {
    space: 'screen', width: 480, height: 72, position: [0.5, 1, 0],
    offset: [0, -24, 0], pivot: 'bottom-center', backgroundColor: 'rgba(11, 10, 21, 0.2)',
    padding: 14, pointerEvents: false,
  })
  const text = app.create('uitext', { fontSize: 14, color: 'rgba(255, 255, 255, 0.65)', value: '', textAlign: 'center' })
  ui.add(text)
  ui.active = false
  app.add(ui)
  const hud = createAimHud(world, app)
  let controlHintMode = null
  let playHintControl = null
  let hintMode = null
  let hoverRefreshPending = false
  let updateAttached = false
  let frameTime = world.getTime()
  let update
  const wake = () => {
    if (!update || updateAttached) return
    updateAttached = true
    frameTime = world.getTime()
    app.on('update', update)
  }
  const isNearby = () => me.position.distanceTo(app.position) < 15
  const setBallsActive = active => {
    for (const ball of balls) ball.active = active
  }
  setBallsActive(isNearby())
  latest?.balls?.forEach((state, i) => {
    balls[i].position.set(state.p[0], R + state.p[2], -state.p[1])
    if (isNearby()) balls[i].active = state.state !== 'InPocket'
  })
  const hoveredTargets = new Set()
  const clearPlayHint = () => {
    playHintControl?.setActions([])
    playHintControl?.release()
    playHintControl = null
    hintMode = null
  }
  const refresh = () => {
    const controlMode = control ? latest?.scratched ? 'place' : 'aim' : null
    if (controlMode !== controlHintMode) {
      controlHintMode = controlMode
      control?.setActions(controlMode === 'aim' ? [{
        type: 'custom', btn: 'W/S · A/D',
        label: 'Spin · Scroll: power · Space: shoot · R: undo · Shift+R: rack · Esc: leave',
        position: 'bottom-left', opacity: .5,
      }] : [])
    }
    const waiting = !cameraHold && hoveredTargets.size > 0 && (shotPending || latest?.moving || latest?.stroke) && me.position.distanceTo(app.position) < 15
    const mode = waiting ? 'waiting' : canPlay() && hoveredTargets.size > 0 ? 'play' : null
    if (mode !== hintMode) {
      if (mode) {
        playHintControl ||= app.control()
        bindReset(playHintControl)
        playHintControl.setActions([mode === 'waiting'
          ? { type: 'hourglass', btn: 'R', label: 'Undo', position: 'pointer', opacity: 0.5 }
          : { type: 'mouseLeft', label: 'Play', position: 'pointer', opacity: 0.5 }])
        hintMode = mode
      } else clearPlayHint()
    }
    app.emit(aimingEvent, !!control)
  }
  for (const target of [surfaceTarget, ...balls]) {
    target.onPointerEnter = () => {
      hoveredTargets.add(target)
      hoverRefreshPending = false
      if (isNearby()) setBallsActive(true)
      refresh()
    }
    target.onPointerLeave = () => {
      hoveredTargets.delete(target)
      // Pointer leave runs before enter when crossing between cloth and balls.
      hoverRefreshPending = true
      wake()
    }
  }
  const clearAimData = () => app.emit(AIM_DATA_EVENT, { playerId: me.id, tableId: app.instanceId, clear: true })
  const clearPose = () => {
    if (posedPlayer) {
      app.emit(poseEvent, { playerId: posedPlayer, tableId: app.instanceId, clear: true })
      world.getPlayer(posedPlayer)?.setPose?.(null, { duration: riseDuration })
      if (posedPlayer === me.id && cameraHold) returnCamera()
    }
    poseMeasurements = null
    aimCue = null
    posedPlayer = null
    posedBody = false
    poseEntryAt = null
    posedBridgeType = null
    cueEntryUntil = 0
  }
  const releaseStroke = () => {
    if (!cameraHold?.holding) return
    cameraHold.holding = false
    app.send('pool:stroke-release', { id: cameraHold.strokeId })
    wake()
  }
  const returnCamera = () => {
    if (!cameraHold || cameraHold.returnAt !== null) return
    const held = cameraHold
    releaseStroke()
    held.returnAt = clock + riseDuration
    app.off('lateUpdate', updateCamera)
    if (held.control) {
      held.control.camera.write = false
      held.control.release()
      held.control = null
    }
    me.setCamera?.({ target: held.target, zoom: 0.3, duration: riseDuration, armsOnly: true })
    refresh()
  }
  const stop = (release = true, keepPose = false) => {
    const active = control
    control = null
    pending = false
    clearAimData()
    if (!keepPose) {
      aimEntry = null
      aimCameraPending = false
      if (strokePlayback) completedStrokeId = Math.max(completedStrokeId, strokePlayback.stroke.id)
      strokePlayback = null
      clearPose()
    }
    if (active) { active.setActions([]); active.camera.write = false; active.release() }
    if (!cameraHold) app.off('lateUpdate', updateCamera)
    if (savedCamera) {
      me.setCamera?.({ ...savedCamera, duration: 0.2 })
      savedCamera = null
    }
    if (release && active) app.send('pool:release', {})
    idle?.release()
    idle = null
    ui.active = ghost.active = false
    hud.hide()
    refresh()
  }
  const request = (operation, data = {}) => app.send(`pool:${operation}`, { ...data, seq: latest?.seq })
  const bindReset = input => {
    input.keyR.capture = true
    input.keyR.onPress = () => {
      if (!hasCue() || !isNearby()) return
      const operation = input.shiftLeft.down || input.shiftRight.down ? 'reset' : 'undo'
      app.send(`pool:${operation}`, { rack: latest?.rack })
    }
  }
  const placeCueBall = () => {
    if (!control || !latest || latest.moving || !latest.scratched || !hasCue()) return false
    request('place', { x: placeX, y: placeY })
    return true
  }
  const begin = () => {
    if (control || !pending || !idle || !hasCue() || latest?.moving) return
    pending = false
    side = top = 0
    if (latest.scratched) { placeX = -size.length / 4; placeY = 0 }
    control = idle
    idle = null
    control.hideReticle()
    for (const key of ['keyW', 'keyA', 'keyS', 'keyD', 'arrowLeft', 'arrowRight', 'arrowUp', 'arrowDown', 'space', 'keyR', 'escape'])
      control[key].capture = true
    control.camera.write = true
    control.camera.zoom = 0
    control.camera.position.copy(aimEntry.position)
    aimCameraPending = true
    app.on('lateUpdate', updateCamera)
    control.scrollDelta.capture = true
    control.space.onPress = () => {
      if (!latest || latest.moving || !hasCue()) return
      if (latest.scratched) placeCueBall()
      else {
        const ball = latest.balls[0].p
        cameraHold = { control: null, returnAt: null, holding: control.space.down, strokeId: latest.seq + 1,
          position: aimCameraPosition?.clone() || control.camera.position.clone(),
          target: worldPosition(new Vector3(ball[0], R + ball[2], -ball[1])) }
        // An early shot finishes lowering during the backswing, before impact.
        if (aimEntry) aimEntry = { at: clock, duration: 0.1,
          position: control.camera.position.clone(), quaternion: control.camera.quaternion.clone() }
        // Visual playback starts on the key press; server packets never reset it.
        strokePlayback = { local: true, elapsed: 0, shots: latest.shots,
          stroke: { id: cameraHold.strokeId, playerId: me.id, ball: ball.slice(),
            angle, speed, side, top, held: cameraHold.holding } }
        savedCamera = null // Return to the shoulder view as the avatar stands.
        shotPending = true
        requestedAt = clock
        shotRequestSeq = latest.seq
        const hold = cameraHold.holding
        const seq = latest.seq
        stop(false, true)
        // Release aiming inputs now; retain the camera and Space release through follow-through.
        cameraHold.control = app.control()
        bindReset(cameraHold.control)
        cameraHold.control.camera.write = true
        cameraHold.control.camera.zoom = 0
        cameraHold.control.scrollDelta.capture = true
        cameraHold.control.space.capture = true
        cameraHold.control.space.onRelease = releaseStroke
        cameraHold.control.escape.capture = true
        cameraHold.control.escape.onPress = () => stop()
        writeAimCamera(cameraHold.control.camera, cameraHold.position, cameraHold.target)
        app.send('pool:shoot', { angle, speed, side, top, animate: true, hold, seq })
        wake()
      }
    }
    control.mouseLeft.onPress = placeCueBall
    bindReset(control)
    control.escape.onPress = () => stop()
    ui.active = true
    sinceAim = 1
    cameraOrbit = 0
    cueElevation = Math.atan(0.045)
    aimStance = null
    const local = me.position.clone().sub(app.position).applyQuaternion(app.quaternion.clone().invert())
    floorY = local.y < -0.35 ? local.y : -0.708
  }
  const receive = snapshot => {
    if (!snapshot || (latest && snapshot.seq <= latest.seq)) return
    if (Object.hasOwn(snapshot, 'aim')) aim = snapshot.aim
    if (shotPending && snapshot.seq > shotRequestSeq) shotPending = false
    if (latest && snapshot.scratched !== latest.scratched && !snapshot.moving) frames = []
    if (latest && snapshot.rack !== latest.rack) {
      if (cameraHold || strokePlayback) stop(false)
      shotPending = false
      frames = []
      soundEvents = []
      sounds.clear()
    }
    if (!latest) lastEventId = snapshot.lastEventId || 0
    for (const event of snapshot.events || []) {
      if (event.id > lastEventId) soundEvents.push(event)
    }
    lastEventId = Math.max(lastEventId, snapshot.lastEventId || 0)
    latest = snapshot
    cueHolders = snapshot.cueHolders || []
    frames.push({ at: clock, snapshot })
    frames = frames.slice(-8)
    if (latest.owner === me.id && !latest.moving && hasCue()) begin()
    else if (control) stop(false, !!cameraHold)
    if (!hasCue() || latest.moving || (latest.owner && latest.owner !== me.id)) pending = false
    // Pose release follows buffered playback in update, rather than the newest packet.
    if (!pending && idle) {
      idle.release()
      idle = null
      aimEntry = null
      savedCamera = null
    }
    refresh()
    wake()
  }
  app.on('pool:snapshot', receive)
  app.on('pool:aim', next => { aim = next; wake() })
  watchCues(world, holders => {
    cueHolders = holders
    if (!hasCue() && (control || cameraHold)) stop()
    refresh()
    wake()
  })
  if (latest) frames = [{ at: clock, snapshot: latest }]
  const play = () => {
    if (!canPlay()) return
    const local = me.position.clone().sub(app.position).applyQuaternion(app.quaternion.clone().invert())
    const ball = latest?.scratched ? [-size.length / 4, 0, 0] : latest?.balls[0]?.p || [-size.length / 4, 0, 0]
    angle = Math.atan2(ball[1] + local.z, ball[0] - local.x)
    pending = true
    requestedAt = clock
    if (isNearby()) setBallsActive(true)
    idle = app.control()
    savedCamera = me.getCamera?.() || null
    // Capture the visible view before the server can teleport the stance.
    // Retain this camera binding through ownership acceptance and the descent.
    aimEntry = { at: null, duration: riseDuration,
      position: idle.camera.position.clone().add(new Vector3(0, 0, idle.camera.zoom || 0)
        .applyQuaternion(idle.camera.quaternion)),
      quaternion: idle.camera.quaternion.clone() }
    idle.camera.position.copy(aimEntry.position)
    idle.camera.zoom = 0
    idle.camera.write = true
    idle.pointer.lock()
    poseMeasurements = playerMeasurements(me)
    app.send('pool:claim', { angle, cueOffset: poseMeasurements.cueOffset })
    refresh()
    wake()
  }
  const playOrPlace = event => {
    if (event?.button !== 'left') return
    if (!placeCueBall()) play()
  }
  for (const target of [surfaceTarget, ...balls]) target.onPointerDown = playOrPlace
  world.on(`${aimingEvent}:request`, refresh)
  refresh()
  app.emit(`${cueEvent}:request`)
  const axis = new Vector3()
  const cameraRotation = new Quaternion()
  const orbitRotation = new Quaternion()
  const cameraUp = new Vector3(0, 1, 0)
  const worldPosition = local => local.clone().multiply(app.scale).applyQuaternion(app.quaternion).add(app.position)
  const writeAimCamera = (camera, position, target) => {
    camera.position.copy(position)
    const boneOptions = { targetPose: !!aimEntry }
    const rightEye = me.getBoneTransform?.('rightEye', boneOptions)
    if (rightEye) camera.position.setFromMatrixPosition(rightEye)
    else {
      const leftEye = me.getBoneTransform?.('leftEye', boneOptions)
      const anchor = leftEye || me.getBoneTransform?.('head', boneOptions)
      if (anchor) {
        camera.position.setFromMatrixPosition(anchor)
        // Missing eye bones: estimate the right eye from the remaining eye or head.
        // Use view-right rather than raw bone axes, which vary between VRMs.
        const height = Number.isFinite(me.height) ? me.height : 1.7
        axis.copy(target).sub(camera.position).cross(cameraUp).normalize()
        camera.position.addScaledVector(axis, (leftEye ? 0.06 : 0.03) * height / 1.7)
      }
    }
    // Keep the whole shaft on the screen centerline, including side spin.
    // Preserve eye height and reach; slide only the view onto the cue's plane.
    if (aimCue) {
      const across = aimCue.across
      camera.position.addScaledVector(across, aimCue.position.clone().sub(camera.position).dot(across))
      target = target.clone().addScaledVector(across, aimCue.position.clone().sub(target).dot(across))
    }
    const look = target.clone().sub(camera.position)
    camera.quaternion.setFromEuler(new Euler(
      Math.atan2(look.y, Math.hypot(look.x, look.z)), Math.atan2(-look.x, -look.z), 0, 'YXZ'))
    // Placement keeps the avatar at the rail, so turn the view around the
    // ball explicitly. Use the same bearing as the placement movement controls.
    if (control && latest?.scratched) {
      const direction = look.clone().applyQuaternion(app.quaternion.clone().invert())
      orbitRotation.setFromAxisAngle(cameraUp, angle - Math.atan2(-direction.z, direction.x))
      camera.position.sub(target).applyQuaternion(orbitRotation).add(target)
      camera.quaternion.premultiply(orbitRotation)
    }
    // Stay above the shaft and on the shooter's side of the ball. Clamp the
    // input itself so reversing at either limit moves the view immediately.
    const eyeElevation = Math.atan2(-look.y, Math.hypot(look.x, look.z))
    cameraOrbit = Math.max(eyeElevation - 85 * Math.PI / 180,
      Math.min(eyeElevation - cueElevation - 0.03, cameraOrbit))
    if (cameraOrbit) {
      axis.set(1, 0, 0).applyQuaternion(camera.quaternion)
      orbitRotation.setFromAxisAngle(axis, cameraOrbit)
      camera.position.sub(target).applyQuaternion(orbitRotation).add(target)
      camera.quaternion.premultiply(orbitRotation)
    }
    if (aimEntry) {
      if (aimEntry.at === null) {
        camera.position.copy(aimEntry.position)
        camera.quaternion.copy(aimEntry.quaternion)
        return
      }
      const t = Math.min(1, Math.max(0, (clock - aimEntry.at) / aimEntry.duration))
      const blend = t * t * (3 - 2 * t)
      camera.position.lerpVectors(aimEntry.position, camera.position, blend)
      camera.quaternion.slerpQuaternions(aimEntry.quaternion, cameraRotation.copy(camera.quaternion), blend)
      if (t === 1) aimEntry = null
    }
  }
  const updateCamera = () => {
    if (control && aimCameraPosition && aimCameraTarget)
      writeAimCamera(control.camera, aimCameraPosition, aimCameraTarget)
    else if (cameraHold?.control)
      writeAimCamera(cameraHold.control.camera, cameraHold.position, cameraHold.target)
    if (control && !aimEntry && !latest?.scratched && !latest?.error && latest?.balls[0]?.p)
      hud.update(control.camera, latest.balls[0].p, angle, side, top, speed, control.screen)
    else hud.hide()
  }
  update = dt => {
    if (!Number.isFinite(dt) || dt <= 0) return
    // Visual time must not inherit the engine physics delta cap at low frame rates.
    const now = world.getTime()
    const visualDelta = Math.max(0, now - frameTime)
    frameTime = now
    clock += visualDelta
    if (aimCameraPending && aimEntry) {
      aimCameraPending = false
      aimEntry.at = clock
      const ball = latest.balls[0].p
      me.setCamera?.({ target: worldPosition(new Vector3(ball[0], R + ball[2], -ball[1])),
        firstPerson: true, headOnly: true, armsOnly: true, duration: aimEntry.duration })
    }
    if (hoverRefreshPending) {
      hoverRefreshPending = false
      refresh()
    }
    if (pending && clock - requestedAt > 2) stop(false)
    if (shotPending && clock - requestedAt > 2) { shotPending = false; stop(false); refresh() }
    const nearby = isNearby()
    if (nearby) setBallsActive(true)
    if (!nearby) { if (control) stop(); clearPose(); sounds.clear(); soundEvents = [] }
    const renderAt = clock - 0.1
    while (frames.length > 1 && frames[1].at <= renderAt) frames.shift()
    const a = frames[0], b = frames[1] || a
    if (a) {
      const alpha = a === b ? 1 : Math.max(0, Math.min(1, (renderAt - a.at) / (b.at - a.at || 1)))
      const displayedTime = a.snapshot.time + (b.snapshot.time - a.snapshot.time) * alpha
      const futureEvents = []
      for (const event of soundEvents) {
        if (event.time > displayedTime) futureEvents.push(event)
        else if (nearby && displayedTime - event.time <= 0.12) sounds.play(event, clock)
      }
      soundEvents = futureEvents
      a.snapshot.balls.forEach((state, i) => {
        const next = b.snapshot.balls[i]
        const p = state.p.map((v, j) => v + (next.p[j] - v) * alpha)
        if (nearby) balls[i].active = state.state !== 'InPocket'
        balls[i].position.set(p[0], R + p[2], -p[1])
        axis.set(state.w[0], state.w[2], -state.w[1])
        const rotationSpeed = axis.length()
        if (rotationSpeed > 0) balls[i].quaternion.premultiply(
          new Quaternion().setFromAxisAngle(axis.multiplyScalar(1 / rotationSpeed), rotationSpeed * Math.min(dt, 0.1)))
      })
    }
    const networkStroke = a?.snapshot.stroke || latest?.stroke
    if (networkStroke && networkStroke.id > completedStrokeId &&
        strokePlayback?.stroke.id !== networkStroke.id) {
      strokePlayback = { local: false, shots: latest.shots,
        elapsed: Math.max(0, networkStroke.elapsed - 0.1), stroke: networkStroke }
    }
    let stroke = strokePlayback?.stroke
    let strokeElapsed = 0
    if (strokePlayback) {
      // Advance from real frame time, independently of packet arrival times.
      strokePlayback.elapsed = Math.min(STROKE_END, strokePlayback.elapsed + Math.min(visualDelta, 0.1))
      strokeElapsed = strokePlayback.elapsed
      const held = strokePlayback.local ? cameraHold?.holding : networkStroke?.id === stroke.id && networkStroke.held
      const cancelled = strokePlayback.local
        ? !shotPending && latest.stroke?.id !== stroke.id
        : !networkStroke && latest.shots === strokePlayback.shots
      if (cancelled || (strokeElapsed >= STROKE_END && !held)) {
        completedStrokeId = Math.max(completedStrokeId, stroke.id)
        strokePlayback = stroke = null
      }
    }
    const restingStroke = stroke && strokeElapsed >= STROKE_END
    const soundsActive = sounds.update(clock)
    if (nearby && control && (me.position.distanceTo(app.position) > 5 || !hasCue())) stop()
    if (control) {
      ping += dt
      if (ping > 15) { ping = 0; app.send('pool:ping', {}) }
      const horizontal = Number(control.arrowRight.down) - Number(control.arrowLeft.down)
      const vertical = Number(control.arrowUp.down) - Number(control.arrowDown.down)
      const pointer = control.pointer.delta
      const turn = horizontal * dt + pointer.x * 0.003
      angle = Math.atan2(Math.sin(angle - turn), Math.cos(angle - turn))
      cameraOrbit -= pointer.y * 0.003
      if (latest?.scratched) {
        const forward = Number(control.keyW.down) - Number(control.keyS.down)
        const right = Number(control.keyD.down) - Number(control.keyA.down)
        const distance = dt * 1.5 / Math.max(1, Math.hypot(forward, right))
        placeX = Math.max(-size.length / 2 + 2 * R, Math.min(size.length / 2 - 2 * R,
          placeX + (Math.cos(angle) * forward + Math.sin(angle) * right) * distance))
        placeY = Math.max(-size.width / 2 + 2 * R, Math.min(size.width / 2 - 2 * R,
          placeY + (Math.sin(angle) * forward - Math.cos(angle) * right) * distance))
      } else {
        // Native scroll is negative when pulling back (the same direction as zooming out).
        speed = Math.max(0.1, Math.min(5, speed + vertical * dt - control.scrollDelta.value * 0.01))
        side += (Number(control.keyD.down) - Number(control.keyA.down)) * dt * 0.3
        top += (Number(control.keyW.down) - Number(control.keyS.down)) * dt * 0.3
        const spin = Math.hypot(side, top)
        if (spin > 0.45) { side *= 0.45 / spin; top *= 0.45 / spin }
      }
      const ball = latest?.scratched ? [placeX, placeY, 0] : latest?.balls[0]?.p
      if (ball && latest) app.emit(AIM_DATA_EVENT, {
        playerId: me.id, tableId: app.instanceId, cue: ball, angle, size, radius: R,
        targets: latest.balls.slice(1).filter(b => b.state !== 'InPocket' && b.state !== 'Falling').map(b => b.p),
        position: app.position.toArray(), quaternion: app.quaternion.toArray(), scale: app.scale.toArray(),
      })
      if (ball) {
        const pose = shotPose(ball, angle, side, top, AIM_ELEVATION, speed)
        aimCameraPosition = worldPosition(pose.cameraPosition)
        aimCameraTarget = worldPosition(pose.cameraTarget)
        // Predict only the local rendered stance. The server validates aim and
        // moves the actual player; its delayed transform cannot pull this view back.
        if (!poseMeasurements) poseMeasurements = playerMeasurements(me)
        const stance = latest.scratched ? placementStance(ball, size, aim?.floorY ?? floorY) :
          avatarStance(ball, angle, size, aim?.floorY ?? floorY, aim?.cueOffset ?? poseMeasurements.cueOffset)
        aimStance = { position: worldPosition(stance.position),
          quaternion: app.quaternion.clone().multiply(stance.quaternion) }
      }
      sinceAim += dt
      if (sinceAim >= 0.1) {
        sinceAim = 0
        app.send('pool:aim', { angle, side, top, speed,
          placement: latest?.scratched ? { x: placeX, y: placeY } : null })
      }
      ui.active = !!latest?.error || !!latest?.scratched
      text.value = latest?.error || (latest?.scratched
        ? 'Scratch · Mouse / ← →: orbit · WASD: move white ball\nClick / Space: confirm · R: re-rack · Esc: leave'
        : '')
    }
    // Move the actual cue from the existing rack, visible to every observer.
    const shooter = latest?.owner
    const placing = shooter && latest.scratched && !latest.moving &&
      (shooter === me.id ? !!control : aim?.playerId === shooter && aim.placement)
    const placementActor = placing ? shooter : null
    const placementPlayer = placementActor && world.getPlayer(placementActor)
    if (nearby && placementActor && cueHolders.includes(placementActor)) {
      const selected = placementActor === me.id ? [placeX, placeY, 0] :
        [aim.placement.x, aim.placement.y, 0]
      // Position the real ball on the cloth, including on observing clients.
      // The hand reaches this position; its animation never lifts the ball.
      balls[0].active = true
      balls[0].position.set(selected[0], R, -selected[1])
      const ball = worldPosition(new Vector3(selected[0], R, -selected[1]))
      if (placementPlayer) {
        if (posedPlayer && posedPlayer !== placementActor) clearPose()
        if (!poseMeasurements) poseMeasurements = playerMeasurements(placementPlayer)
        const stance = placementActor === me.id && aimStance || placementPlayer
        const placement = playerPlacementPose(stance, ball, poseMeasurements, R * app.scale.y)
        // Native root prediction is local-only. Observers solve the same
        // body and hands relative to the remote player's accepted transform.
        if (placementActor !== me.id) delete placement.pose.root
        const entering = posedPlayer !== placementActor
        placementPlayer.setPose?.(placement.pose, { duration: entering ? 0.25 : 0 })
        posedPlayer = placementActor
        posedBody = false
        aimCue = null
        app.emit(poseEvent, { playerId: placementActor, tableId: app.instanceId,
          position: placement.cuePosition.toArray(), quaternion: placement.cueQuaternion.toArray(), followGrip: true })
      }
    }
    ghost.active = false
    const aiming = shooter && !latest.moving && !latest.scratched &&
      (shooter === me.id ? !!control : aim?.playerId === shooter)
    const actor = stroke?.playerId || (aiming ? shooter : null)
    const player = actor && world.getPlayer(actor)
    if (nearby && player && cueHolders.includes(actor) && (stroke || aiming)) {
      const params = actor === me.id ? { angle, side, top, speed } : aim
      const pose = stroke ? strokePose(stroke, strokeElapsed) :
        shotPose(latest.balls[0].p, params.angle, params.side, params.top, AIM_ELEVATION, params.speed)
      if (posedPlayer && posedPlayer !== actor) clearPose()
      if (poseMeasurements && Number.isFinite(player.height) && Math.abs(player.height - poseMeasurements.height) > 0.05) {
        player.setPose?.(null)
        poseMeasurements = null
        posedBody = false
        poseEntryAt = null
        posedBridgeType = null
      }
      if (!poseMeasurements) poseMeasurements = playerMeasurements(player)
      posedPlayer = actor
      if (actor === me.id && cameraHold) cameraHold.returnAt = null
      const cuePosition = worldPosition(pose.cuePosition)
      const cueQuaternion = app.quaternion.clone().multiply(pose.cueQuaternion)
      const predicted = actor === me.id && (control || cameraHold) && aimStance
      const { bridgeType, ...avatarPose } = playerAimPose(predicted || player, cuePosition, cueQuaternion,
        worldPosition(pose.cameraTarget), poseMeasurements, { position: app.position, quaternion: app.quaternion, size })
      if (actor === me.id) {
        const shaft = new Vector3(0, 1, 0).applyQuaternion(cueQuaternion)
        cueElevation = Math.atan2(-shaft.y, Math.hypot(shaft.x, shaft.z))
        aimCue = { position: cuePosition.clone(), across: shaft.cross(cameraUp).normalize() }
      }
      if (predicted) avatarPose.root = { position: predicted.position.toArray(),
        quaternion: predicted.quaternion.toArray() }
      const entering = !posedBody && !stroke
      const earlyShot = stroke && ((actor === me.id && !posedBody) ||
        (poseEntryAt !== null && clock - poseEntryAt < riseDuration))
      // Start the native timer once at a bridge change. Later aim updates keep
      // its destination current without making progress depend on the angle.
      const bridgeChanged = posedBridgeType !== null && posedBridgeType !== bridgeType && !stroke
      if (entering) cueEntryUntil = clock + riseDuration
      else if (earlyShot) cueEntryUntil = clock + 0.1
      if (bridgeChanged) cueEntryUntil = 0
      player.setPose?.(avatarPose, { duration: entering ? riseDuration : earlyShot ? 0.1 : bridgeChanged ? 0.5 : 0 })
      posedBridgeType = bridgeType
      if (entering) poseEntryAt = clock
      if (stroke) poseEntryAt = null
      posedBody = true
      app.emit(poseEvent, { playerId: actor, tableId: app.instanceId,
        position: cuePosition.toArray(), quaternion: cueQuaternion.toArray(), followGrip: clock < cueEntryUntil })
    } else if (!placementActor && !shotPending) clearPose()
    if (cameraHold) {
      if (cameraHold.returnAt === null && !shotPending && !stroke && posedPlayer !== me.id) returnCamera()
      if (cameraHold.returnAt !== null && clock - cameraHold.returnAt > 1e-8) {
        cameraHold = null
        refresh()
      }
    }
    // Stop native frame dispatch once interpolation, sounds and input are idle.
    if (!control && (!cameraHold || restingStroke) && !pending && !shotPending && (!stroke || restingStroke) && !hoverRefreshPending && !latest?.moving &&
        frames.length <= 1 && soundEvents.length === 0 && !soundsActive) {
      app.off('update', update)
      updateAttached = false
    }
  }
  if (latest?.moving || latest?.owner || latest?.stroke) wake()
  app.on('destroy', () => {
    stop()
    returnCamera()
    cameraHold = null
    clearPlayHint()
    hud.destroy()
  })
}
