import { Vector3, Quaternion, Euler } from 'three'
import { BALL_RADIUS as R } from './simulation.js'

// All poses are table-local (+Y up, physics +Y maps to -Z).
export const AIM_ELEVATION = Math.atan2(0.14, 0.68)
export function placementStance(position, size, floorY) {
  // Place from the nearest rail; orbiting the view must not require reaching
  // across the entire length of the table with the ball in hand.
  const x = position[0], z = -position[1]
  const end = size.length / 2 - Math.abs(x) < size.width / 2 - Math.abs(z)
  const outward = end ? new Vector3(x < 0 ? -1 : 1, 0, 0) :
    new Vector3(0, 0, z < 0 ? -1 : 1)
  const distance = (end ? size.length / 2 - Math.abs(x) : size.width / 2 - Math.abs(z)) + 0.52
  return {
    position: new Vector3(x, floorY, z).addScaledVector(outward, distance),
    quaternion: new Quaternion().setFromUnitVectors(new Vector3(0, 0, -1), outward.negate()),
  }
}
export function avatarStance(position, angle, size, floorY, cueOffset = 0.28) {
  const forward = new Vector3(Math.cos(angle), 0, -Math.sin(angle))
  const across = new Vector3(Math.sin(angle), 0, Math.cos(angle))
  const origin = new Vector3(position[0], floorY, -position[1]).addScaledVector(across, -cueOffset)
  const backward = forward.clone().negate()
  // Rail exterior is about 18 cm beyond the playing surface. Include the
  // native player's 30 cm capsule radius, then step beyond that rectangle.
  const halfX = size.length / 2 + 0.18 + 0.3
  const halfZ = size.width / 2 + 0.18 + 0.3
  const exitX = Math.abs(backward.x) < 1e-9 ? Infinity :
    (Math.sign(backward.x) * halfX - origin.x) / backward.x
  const exitZ = Math.abs(backward.z) < 1e-9 ? Infinity :
    (Math.sign(backward.z) * halfZ - origin.z) / backward.z
  const distance = Math.max(1.20, Math.min(exitX, exitZ) + 0.04)
  return {
    position: origin.addScaledVector(backward, distance),
    // Turn the body slightly across the cue line: left shoulder forward, grip
    // shoulder back. Facing the cue squarely folds the bridge arm across the chest.
    quaternion: new Quaternion().setFromEuler(new Euler(0, angle - Math.PI / 2 - 0.35, 0, 'YXZ')),
    distance,
  }
}

export function shotPose(position, angle, side = 0, top = 0, elevation = AIM_ELEVATION, speed = 2.5) {
  const ball = new Vector3(position[0], R + position[2], -position[1])
  const forward = new Vector3(Math.cos(angle), 0, -Math.sin(angle))
  const across = new Vector3(Math.sin(angle), 0, Math.cos(angle))
  const cameraPosition = ball.clone().addScaledVector(forward, -0.68)
  cameraPosition.y += Math.tan(elevation) * 0.68
  const look = ball.clone().sub(cameraPosition)
  const cameraQuaternion = new Quaternion().setFromEuler(new Euler(
    Math.atan2(look.y, Math.hypot(look.x, look.z)), Math.atan2(-look.x, -look.z), 0, 'YXZ'))
  const cueDirection = forward.clone()
  cueDirection.y = -0.045
  cueDirection.normalize()
  const contact = ball.clone().addScaledVector(across, side * R)
  contact.y += top * R
  // A 1.47 m cue, positive local Y toward the chalk tip.
  // Reserve 2 cm for the backswing within the grip arm's 16 cm travel.
  const pullback = Math.max(0, Math.min(1, (speed - 0.1) / 4.9)) * 0.14
  const gap = R * Math.sqrt(Math.max(0, 1 - side * side - top * top)) + 0.012 + pullback
  const cuePosition = contact.clone().addScaledVector(cueDirection, -(0.735 + gap))
  const cueQuaternion = new Quaternion().setFromUnitVectors(new Vector3(0, 1, 0), cueDirection)
  return { cameraPosition, cameraQuaternion, cameraTarget: ball, cuePosition, cueQuaternion, cueDirection, contactPosition: contact, pullback }
}
